GasMobil shared branding kit
Copy the apps/ folder into the repository root in Codespaces, preserving the folder paths.
This supplies the GasMobil icon, dark login background, and customer-site LPG cylinder artwork.
